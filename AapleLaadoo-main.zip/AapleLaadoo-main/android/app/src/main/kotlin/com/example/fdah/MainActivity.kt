package com.example.AapleLaadoo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
